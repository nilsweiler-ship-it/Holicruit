# holicruit app icons — Option A (ring on ink)

Exported from the recommended brand mark. Palette is the brand palette (no separate colors invented):
**Ink `#161514`** background · **Coral `#E0533D`** + **Cream `#F4EFE7`** arcs.

All icons are **square and fully opaque** (no transparency, no pre-rounded corners) — this is the master format the App Store, iOS, and Android all expect; each platform masks its own corner radius. Two web favicons and a rounded showcase tile are the exceptions.

## What's here
| File | Use |
|---|---|
| `icon-1024.png` | **App Store Connect** marketing icon (required, square, opaque). |
| `icon-512.png` | Google **Play Store** listing icon. |
| `icon-180 / 167 / 152 / 120 / 87 / 80 / 76 / 60 / 58 / 40 / 29 / 20.png` | iOS / iPadOS app icon set (@1x–@3x across devices & settings/spotlight). |
| `icon-192 / 144 / 96 / 72 / 48.png` | Android launcher (mdpi→xxxhdpi) / PWA `manifest` icons. |
| `icon-128.png` | General / desktop. |
| `favicon-32.png`, `favicon-16.png` | Browser tab favicons (slightly rounded for legibility). |
| `tile-rounded-1024.png` | Marketing/showcase tile with rounded corners — **not** for store upload. |

## Notes for engineers
- **PWA maskable:** the ring sits at ~62% of the tile, inside the 80% maskable safe zone, so any square `icon-*.png` doubles as a `purpose: "maskable"` icon. Add to `manifest.json` as needed.
- **Do not round the store uploads.** Apple rejects icons with an alpha channel or baked-in rounded corners; use the square `icon-*.png` set as-is.
- Source of truth for the mark and palette: `../Holicruit Logo.dc.html`.
